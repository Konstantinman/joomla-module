<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;

class ModTagsByCategoryHelper
{
    public static function getTags()
    {
        $app = Factory::getApplication();
        $input = $app->getInput();
        $option = $input->getCmd('option');
        $view = $input->getCmd('view');
        $id = (int) $input->getInt('id');

        if ($option !== 'com_content' || $view !== 'category' || !$id) {
            return [];
        }

        $db = Factory::getDbo();

        $query = $db->getQuery(true)
            ->select('DISTINCT t.id, t.title, t.alias')
            ->from('#__tags AS t')
            ->join('INNER', '#__contentitem_tag_map AS m ON t.id = m.tag_id')
            ->join('INNER', '#__content AS c ON m.content_item_id = c.id')
            ->where('c.catid = ' . (int) $id)
            .where('c.state = 1')
            .order('t.title ASC');

        $db->setQuery($query);

        return $db->loadObjectList();
    }
}
