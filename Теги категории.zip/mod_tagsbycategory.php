<?php
defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

$tags = ModTagsByCategoryHelper::getTags();

require JModuleHelper::getLayoutPath('mod_tagsbycategory', $params->get('layout', 'default'));
