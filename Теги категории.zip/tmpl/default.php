<?php
defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;

if (!empty($tags)) : ?>
    <p><strong><?php echo Text::_('Tags'); ?>:</strong>
        <?php
        $tagLinks = array();
        foreach ($tags as $tag) {
            $url = Route::_('index.php?option=com_tags&view=tag&id=' . $tag->id . ':' . $tag->alias);
            $tagLinks[] = '<a href="' . $url . '">' . htmlspecialchars($tag->title) . '</a>';
        }
        echo implode(', ', $tagLinks);
        ?>
    </p>
<?php else : ?>
    <p><?php echo Text::_('MOD_TAGSBYCATEGORY_NO_TAGS_FOUND'); ?></p>
<?php endif; ?>
